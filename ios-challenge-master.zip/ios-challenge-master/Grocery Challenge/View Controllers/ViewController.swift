//
//  ViewController.swift
//  Grocery Challenge
//
//  Created by Andrew Crookston on 5/14/18.
//  Copyright © 2018 Instacart. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var question: UILabel!
    @IBOutlet weak var collectionView: UICollectionView!
    @IBOutlet weak var submit: UIButton!
    
    var selectedIndexPath: IndexPath?
    
    var viewModel = GroceryChallegeViewModel()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setUpCollectionView()
        viewModel.delegate = self
        viewModel.getRandomQuestion()
    }
    
    func setUpCollectionView() {
        collectionView.delegate = self
        collectionView.dataSource = self
        collectionView.register(InstacartCell.self, forCellWithReuseIdentifier: InstacartCell.reuseId)
        collectionView.register(UICollectionViewCell.self, forCellWithReuseIdentifier: "empty")
        
    }
}

extension ViewController: UICollectionViewDelegate {
    
    
    
    
    
}

extension ViewController: UICollectionViewDelegateFlowLayout {
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        
        let width = (collectionView.frame.width)/2 - 20
        let height = (collectionView.frame.height)/2 - 20
        return CGSize(width: width, height: height)
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumInteritemSpacingForSectionAt section: Int) -> CGFloat {
        return 1
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAt section: Int) -> CGFloat {
        return 1
    }
    
}

extension ViewController: UICollectionViewDataSource {
    
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        return 1
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return 4
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        let emptyCell = collectionView.dequeueReusableCell(withReuseIdentifier: "empty", for: indexPath)
        
        guard let cell  = collectionView.dequeueReusableCell(withReuseIdentifier: InstacartCell.reuseId, for: indexPath) as? InstacartCell, !viewModel.answers.isEmpty else {
            return emptyCell
        }
        cell.configureImage(with: viewModel.answers[indexPath.row].url)
        return cell
    }
    
}

extension ViewController: ChallegeFetchDelegate {
    func didFetchQuestions() {
        DispatchQueue.main.async { [weak self] in
            guard let question = self?.viewModel.question else {
                return
            }
            self?.question.text = question.query
            self?.collectionView.reloadData()
        }
    }
}

