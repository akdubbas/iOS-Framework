//
//  InstacartCell.swift
//  Grocery Challenge
//
//  Created by Amith Dubbasi on 1/31/20.
//  Copyright © 2020 Instacart. All rights reserved.
//

import Foundation

class InstacartCell: UICollectionViewCell {
    
    static let reuseId = "instacartCell"
    
    let imageView: UIImageView = {
        let imageView = UIImageView()
        imageView.contentMode = .scaleAspectFit
        return imageView
    }()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        configureUI()
    }
    
    required init?(coder: NSCoder) {
        super.init(coder: coder)
    }
    
    func configureUI() {
        addSubview(imageView)
        imageView.translatesAutoresizingMaskIntoConstraints = false
    
        NSLayoutConstraint.activate([
            imageView.leftAnchor.constraint(equalTo: leftAnchor, constant: 8.0),
            imageView.topAnchor.constraint(equalTo: topAnchor, constant: 8.0),
            imageView.rightAnchor.constraint(equalTo: rightAnchor, constant: -8.0),
            imageView.bottomAnchor.constraint(equalTo: bottomAnchor, constant: 8.0),
            imageView.widthAnchor.constraint(equalToConstant: 0.0),
            imageView.heightAnchor.constraint(equalToConstant: 0.0)
        ])
    }
    
    func configureImage(with url: URL) {
        UIImage.asyncFrom(url: url) { [weak self] (result) in
            guard let self = self else {
                return
            }
            switch result {
            case .success(let image):
                DispatchQueue.main.async {
                    self.imageView.image = image
                }
            case .error(let error):
                print("\(error.localizedDescription)")
            }
        }
    }
}
