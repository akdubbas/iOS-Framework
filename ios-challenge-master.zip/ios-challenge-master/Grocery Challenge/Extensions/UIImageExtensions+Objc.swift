//
//  UIImageExtensions+Objc.swift
//  Grocery Challenge
//
//  Created by Florent Bories on 10/10/19.
//  Copyright © 2019 Instacart. All rights reserved.
//

import Foundation

extension UIImage {
    /// Usage:
    /// ```
    /// [UIImage asyncFromURL:(NSURL *url) success:^(UIImage *image) {
    ///     NSLog(@"%@", image);
    /// } failure:^(NSError *error) {
    ///     NSLog(@"%@", error);
    /// }];
    /// ```
    @objc(asyncFromURL:success:failure:) static func bridgedAsyncFrom(url: URL, success: @escaping ((UIImage) -> Void), failure: @escaping ((Error) -> Void)) {
        asyncFrom(url: url) { result in
            switch result {
            case .success(let image):
                success(image)
            case .error(let error):
                failure(error)
            }
        }
    }
}
