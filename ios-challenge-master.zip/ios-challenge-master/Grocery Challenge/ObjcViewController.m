//
//  ObjcViewController.m
//  Grocery Challenge
//
//  Created by Andrew Crookston on 11/15/18.
//  Copyright © 2018 Instacart. All rights reserved.
//

#import "ObjcViewController.h"
#import "Grocery_Challenge-Swift.h"

@interface ObjcViewController ()

@end

@implementation ObjcViewController

- (void)viewDidLoad {
    [super viewDidLoad];
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
