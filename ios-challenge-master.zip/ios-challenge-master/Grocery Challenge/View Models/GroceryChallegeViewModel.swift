//
//  GroceryChallegeViewModel.swift
//  Grocery Challenge
//
//  Created by Amith Dubbasi on 1/31/20.
//  Copyright © 2020 Instacart. All rights reserved.
//

import Foundation

protocol ChallegeFetchDelegate: class {
    func didFetchQuestions()
}

class GroceryChallegeViewModel {
    
    let challegeApi = ChallengeAPI()
    weak var delegate: ChallegeFetchDelegate?
    
    var question: Question?
    var answers: [Answer] = []
    
    func getRandomQuestion() {
        
        challegeApi.randomQuestionAsync { [weak self] result in
            
            guard let self = self else {
                return
            }
            switch result {
            case .success(let question):
                self.question = question
                self.answers = question.answers
                self.delegate?.didFetchQuestions()
            case .error(let error):
                print("\(error.localizedDescription)")
                self.question = nil
            }
        }
    }

}
